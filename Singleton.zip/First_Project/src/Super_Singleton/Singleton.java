package Super_Singleton;

/*
 * CODIGO SINGLETON
 * Finalizado el: 16/08/24
 * Desarrollado por: Fernando Sánchez González
 */
public class Singleton {
 //Instancia única de la clase, inicialmente null
 private static Singleton instance;

 //Constructor privado para evitar instanciación directa
 private Singleton() {
     //Código de inicialización si es necesario
     System.out.println("Instancia de Singleton creada");
 }

 //Método estático para obtener la instancia única
 public static Singleton getInstance() {
     if (instance == null) {
         instance = new Singleton(); //Crear la instancia si aún no existe
     }
     return instance;
 }

 //Método de ejemplo para mostrar que es el mismo objeto
 public void showMessage() {
     System.out.println("El Singleton a funcionado!");
 }
}

