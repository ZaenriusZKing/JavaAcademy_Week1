package Super_Singleton;

/*
 * CODIGO SINGLETON
 * Finalizado el: 16/08/24
 * Desarrollado por: Fernando Sánchez González
 */
public class Main {
 public static void main(String[] args) {
     //Aqui obtenemos la instancia única de Singleton
     Singleton singleton1 = Singleton.getInstance();
     singleton1.showMessage(); // Salida: Hola desde Singleton!
     
     //Intentamos obtener la instancia otra vez
     Singleton singleton2 = Singleton.getInstance();
     singleton2.showMessage(); // Salida: Hola desde Singleton!

     //Comprobamos si ambas instancias son iguales
     if (singleton1 == singleton2) {
         System.out.println("Ambas referencias apuntan al mismo objeto Singleton");
     } else {
         System.out.println("Las referencias son diferentes, algo salió mal");
     }
 }
}


