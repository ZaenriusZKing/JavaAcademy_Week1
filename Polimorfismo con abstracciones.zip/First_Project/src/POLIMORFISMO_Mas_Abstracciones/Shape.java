package POLIMORFISMO_Mas_Abstracciones;

/*
 * CODIGO POLIMORFISMO con abstracciones
 * Finalizado el: 15/08/24
 * Desarrollado por: Fernando Sánchez González
 */
public abstract class Shape {
 //El Método abstracto que debe ser implementado por las subclases
 public abstract void draw();

 //Este es el Método no abstracto opcional, que puede ser compartido entre todas las subclases
 public void display() {
     System.out.println("Dibujando una forma...");
 }
}

