package POLIMORFISMO_Mas_Abstracciones;

/*
 * CODIGO POLIMORFISMO con abstracciones
 * Finalizado el: 15/08/24
 * Desarrollado por: Fernando Sánchez González
 */

public class Main {
 public static void main(String[] args) {
     //Polimorfismo: una referencia de Shape puede apuntar a cualquier subclase de Shape
     Shape circle = new Circle();
     Shape rectangle = new Rectangle();

     //Todas las llamadas polimórficas al método draw()
     circle.display();  //Muestra "Dibujando una forma..."
     circle.draw();     //Muestra "Dibujando un Círculo"
     
     rectangle.display();  //Muestra "Dibujando una forma..."
     rectangle.draw();     //Muestra "Dibujando un Rectángulo"
 }
}

