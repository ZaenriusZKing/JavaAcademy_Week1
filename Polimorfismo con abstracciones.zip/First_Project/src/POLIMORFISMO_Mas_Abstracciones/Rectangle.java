package POLIMORFISMO_Mas_Abstracciones;

/*
 * CODIGO POLIMORFISMO con abstracciones
 * Finalizado el: 15/08/24
 * Desarrollado por: Fernando Sánchez González
 */
public class Rectangle extends Shape {
 @Override
 public void draw() {
     System.out.println("Se a dibujado un rectangulo muy rectangular!");
 }
}

